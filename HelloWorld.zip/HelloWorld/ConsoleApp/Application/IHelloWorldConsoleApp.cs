﻿/*
 date:08/27/2016
 name:Chinonso Maduakolam
 */
namespace ConsoleApp.Application
{
    /// <summary>
    ///     Hello World Console Application
    /// </summary>
    public interface IHelloWorldConsoleApp
    {
        /// <summary>
        ///     Runs the main Hello World Console Application
        /// </summary>
        /// <param name="arguments">The command line arguments.</param>
        void Run(string[] arguments);
    }
}