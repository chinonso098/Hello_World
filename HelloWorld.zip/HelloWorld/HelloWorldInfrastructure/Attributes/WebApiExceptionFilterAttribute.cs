﻿/*
 date:08/27/2016
 name:Chinonso Maduakolam
 */

namespace HelloWorldInfrastructure.Attributes
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http.Filters;
    using HelloWorldInfrastructure.Models;
    using HelloWorldInfrastructure.Resources;
    using HelloWorldInfrastructure.Services;

    /// <summary>
    ///     Severity code enumeration
    /// </summary>
    public enum SeverityCode
    {
        /// <summary>
        ///     No severity level
        /// </summary>
        None,

        /// <summary>
        ///     Information severity level
        /// </summary>
        Information,

        /// <summary>
        ///     Warning severity level
        /// </summary>
        Warning,

        /// <summary>
        ///     Error severity level
        /// </summary>
        Error,

        /// <summary>
        ///     Critical severity level
        /// </summary>
        Critical
    }

    /// <summary>
    ///     A customer exception filter attribute class for globally handling exceptions and creating a Http Response Message
    /// </summary>
    [AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
    public class WebApiExceptionFilterAttribute : ExceptionFilterAttribute
    {
        /// <summary>
        ///     Gets or sets the exception type
        /// </summary>
        public Type Type { get; set; }

        /// <summary>
        ///     Gets or sets the http status code
        /// </summary>
        public HttpStatusCode Status { get; set; }

        /// <summary>
        ///     Gets or sets the severity
        /// </summary>
        public SeverityCode Severity { get; set; }

    }
}